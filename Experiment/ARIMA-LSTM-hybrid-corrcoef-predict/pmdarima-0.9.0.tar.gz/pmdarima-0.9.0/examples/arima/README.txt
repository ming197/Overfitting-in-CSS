.. _arima_examples:

ARIMA examples
--------------

Examples of how to use the :mod:`pyramid.arima` module to fit timeseries
models.

.. raw:: html

   <br/>
