.. _datasets_examples:

Datasets examples
-----------------

Examples of how to use the :mod:`pyramid.datasets` module to conveniently load
toy time series data for model benchmarking and experimentation.

.. raw:: html

   <br/>
