..
    File to ..include in the API ref document.

.. raw:: html

    <style type="text/css">
        h1 {
            /* margin: 0 -10px 0 -10px; */
            text-align: center;
            background-color: #cde8ef;
            /* font-family: Helvetica, Arial, sans-serif; */
            /* font-size: 190%; */
            border-radius: 0 15px 0 15px;
            -moz-border-radius: 0 15px 0 15px;
            padding: 10px;
        }

        h2 {
            background-color: #BED4EB;
            border-radius: 10px;
            padding: 10px;
        }

        h3 {
            padding: 5px;
            border-radius: 10px;
            background-color: #eee;
        }
    </style>
