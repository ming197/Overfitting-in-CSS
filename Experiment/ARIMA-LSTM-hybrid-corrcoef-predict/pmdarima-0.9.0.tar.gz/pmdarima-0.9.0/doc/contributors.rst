.. _contributors:

============
Contributors
============

Thanks to the following users for their contributions to Pyramid!

.. raw:: html

    <!-- Block section -->
    <script src="_static/js/jquery.min.js"></script>

    <!-- This does all the heavy lifting -->
    <script src="_static/js/contrib.js"></script>
    <script type="text/javascript">
        // actually call the contrib code
        $(document).ready(function() {
            fetchContributors();
        });
    </script>

    <!-- This is taken from the Github contrib page -->
    <ol id="contrib" class="contrib-data capped-cards clearfix"></ol>